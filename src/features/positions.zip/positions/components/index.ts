export * from "./definition-tab";

// export { StrategyMapTab } from "./strategy-map-tab";
// export { NodoObjetivo } from "./nodo-objetivo";
// export { NodoPerspectiva } from "./nodo-perspectiva";
