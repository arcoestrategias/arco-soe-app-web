export type User = {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  username?: string | null;
  ide?: string | null;
  telephone?: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
};

export type CreateUserPayload = {
  email: string;
  firstName: string;
  lastName: string;
  username?: string | null;
  ide?: string | null;
  telephone?: string | null;
  password: string; // requerido en create (según tu DTO)
};

export type CreateUserAssignPayload = CreateUserPayload & {
  roleId: string; // requerido
  businessUnitId: string; // requerido
};

export type UpdateUserPayload = Partial<Omit<CreateUserPayload, "password">> & {
  isActive?: boolean; // inactivar con { isActive:false }
  roleId?: string;
  businessUnitId?: string;
  isResponsible?: boolean;
  copyPermissions?: boolean;
  sendEmailConfirmation?: boolean;
};

export type Role = { id: string; name: string };
