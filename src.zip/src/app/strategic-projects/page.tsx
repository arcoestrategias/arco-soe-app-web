"use client";

import * as React from "react";
import { useState } from "react";

import { SidebarLayout } from "@/shared/layout";
import { getBusinessUnitId } from "@/shared/auth/storage";

// Selects reutilizables
import { StrategicPlanSelect } from "@/shared/filters/components/StrategicPlanSelect";
import { PositionSelect } from "@/shared/filters/components/PositionSelect";

// Dashboard de proyectos
import { StrategicProjectsDashboard } from "@/features/strategic-projects/components/project-dashboard";

// Wrapper de etiqueta/ayuda para filtros
import { FilterField } from "@/shared/components/FilterField";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

export default function StrategicProjectsPage() {
  const businessUnitId = getBusinessUnitId() ?? undefined;

  // Estados controlados por la página
  const [planId, setPlanId] = useState<string | null>(null);
  const [positionId, setPositionId] = useState<string | null>(null);

  return (
    <SidebarLayout
      currentPath="/strategic-projects"
      pageTitle="Proyectos Estratégicos"
      onNavigate={() => {}}
    >
      <div className="space-y-6 font-system">
        {/* Encabezado + Filtros (mismo patrón que Positions) */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 heading-optimized">
              Proyectos Estratégicos
            </h1>
            <p className="text-sm text-gray-600 text-optimized mt-1">
              Gestiona y monitorea el progreso de todos los proyectos
              estratégicos
            </p>
          </div>

          <div className="flex gap-3">
            {/* Plan Estratégico: autoselect más reciente, persist y clearOnUnmount */}
            <div className="w-64">
              <FilterField label="Plan estratégico">
                <StrategicPlanSelect
                  businessUnitId={businessUnitId}
                  value={planId}
                  onChange={setPlanId}
                  persist
                  clearOnUnmount
                />
              </FilterField>
            </div>

            {/* Posición: autoselect posición del usuario si existe en la BU */}
            <div className="w-64">
              <FilterField label="Posición">
                <PositionSelect
                  businessUnitId={businessUnitId}
                  value={positionId}
                  onChange={setPositionId}
                  defaultFromAuth
                  persist
                  clearOnUnmount
                />
              </FilterField>
            </div>
            <div>
              <FilterField label="Crear un nuevo proyecto">
                <Button className="h-9 btn-gradient">
                  <Plus className="h-4 w-4 mr-2" />
                  Nuevo Proyecto
                </Button>
              </FilterField>
            </div>
          </div>
        </div>

        {/* Dashboard: recibe los IDs seleccionados desde la página */}
        <StrategicProjectsDashboard
          strategicPlanId={planId ?? undefined}
          positionId={positionId ?? undefined}
        />
      </div>
    </SidebarLayout>
  );
}
