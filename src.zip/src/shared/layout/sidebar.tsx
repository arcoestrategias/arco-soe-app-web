"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState, useMemo } from "react";
import Image from "next/image";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { navigationSections } from "@/shared/layout/navigation";
import type { SidebarProps } from "@/shared/layout/types";
import { useAuth } from "@/features/auth/context/AuthContext";
import { hasAccess } from "../auth/access-control";
import Link from "next/link";

const norm = (p?: string) =>
  p ? (p.endsWith("/") && p !== "/" ? p.slice(0, -1) : p) : "";

export function Sidebar({
  currentPath,
  onLogout,
  onToggle,
  onNavigate,
}: SidebarProps) {
  const router = useRouter();
  const [isCollapsed, setIsCollapsed] = useState(true);
  const [isHovered, setIsHovered] = useState(false);
  const { me } = useAuth();
  const isAdmin = !!me?.isPlatformAdmin;

  const shouldShowExpanded = !isCollapsed || isHovered;

  useEffect(() => {
    const saved = localStorage.getItem("sidebar-collapsed");
    if (saved !== null) setIsCollapsed(saved === "true");
  }, []);

  useEffect(() => {
    onToggle?.(isCollapsed);
  }, [isCollapsed]);

  const toggleCollapsed = () => {
    const next = !isCollapsed;
    setIsCollapsed(next);
    localStorage.setItem("sidebar-collapsed", String(next));
    onToggle?.(next);
  };

  const sections = navigationSections
    .map((sec) => ({
      ...sec,
      items: sec.items.filter((it: any) => {
        if (it.adminOnly) return isAdmin;
        if (!it.module) return true;
        return hasAccess(me, it.module, "access");
      }),
    }))
    .filter((sec) => sec.items.length > 0);

  const flatItems = useMemo(
    () =>
      sections.flatMap((s) =>
        s.items.map((it: any) => ({ ...it, url: norm(it.url) }))
      ),
    [sections]
  );

  const now = norm(currentPath || "");
  const activeUrl = useMemo(() => {
    const exact = flatItems.find((it) => now === it.url)?.url;
    if (exact) return exact;
    const pref = flatItems
      .map((it) => it.url)
      .filter((u) => now.startsWith(u + "/"))
      .sort((a, b) => b.length - a.length);
    return pref[0] ?? "";
  }, [flatItems, now]);

  return (
    <TooltipProvider>
      <aside
        role="navigation"
        aria-label="Sidebar navigation"
        className={cn(
          "fixed left-0 top-0 h-svh min-h-0 bg-white border-r border-gray-200 z-40 transition-all duration-300 ease-in-out overflow-hidden font-system flex flex-col",
          shouldShowExpanded ? "w-64" : "w-16"
        )}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* ===== Header con LOGO (fix colapsado) ===== */}
        <div
          className={cn(
            "h-16 flex items-center justify-between border-b",
            shouldShowExpanded ? "px-4" : "px-2"
          )}
        >
          <div className="flex items-center gap-2 overflow-hidden">
            {shouldShowExpanded ? (
              // Logo grande en expandido
              <div className="relative w-36 h-10 shrink-0">
                <Image
                  src="/logo-soe-black.svg"
                  alt="SOE"
                  fill
                  className="object-contain"
                  priority
                  sizes="144px"
                />
              </div>
            ) : (
              // Ícono en colapsado (hay espacio real ahora)
              <div className="relative w-10 h-10 mx-auto shrink-0">
                <Image
                  src="/logo-soe-icon.svg"
                  alt="SOE Icon"
                  fill
                  className="object-contain"
                  priority
                  sizes="40px"
                />
              </div>
            )}
          </div>

          {/* Oculta COMPLETAMENTE el botón en colapsado para que no ocupe ancho */}
          {shouldShowExpanded ? (
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleCollapsed}
              className="h-8 w-8 text-gray-400 hover:text-gray-600 transition-all duration-300 ease-in-out"
              aria-label={isCollapsed ? "Expandir sidebar" : "Colapsar sidebar"}
            >
              <ChevronRight
                className={cn(
                  "h-4 w-4 transition-transform duration-300 ease-in-out",
                  isCollapsed ? "-rotate-180" : "rotate-0"
                )}
              />
            </Button>
          ) : null}
        </div>

        {/* ===== Navegación ===== */}
        <nav className="flex-1 min-h-0 overflow-y-auto overscroll-contain py-4 pr-1">
          {sections.map((section, i) => (
            <div
              key={section.title}
              className={cn("mb-6", i > 0 && "border-t pt-4 border-gray-100")}
            >
              <div
                className={cn(
                  "px-6 mb-3 transition-all duration-300 ease-in-out",
                  shouldShowExpanded
                    ? "opacity-100 h-auto"
                    : "opacity-0 h-0 overflow-hidden"
                )}
              >
                <h3 className="text-xs font-semibold uppercase text-gray-500 tracking-wide">
                  {section.title}
                </h3>
              </div>

              <div className="space-y-1 px-3">
                {section.items.map((item: any) => {
                  const isActive = norm(item.url) === activeUrl;

                  return (
                    <ul key={item.title}>
                      <Link
                        href={item.url}
                        prefetch
                        className={cn(
                          "group flex items-center w-full transition-all rounded-lg px-3 py-2.5 cursor-pointer",
                          isActive
                            ? "bg-orange-50 text-orange-600"
                            : "text-gray-700 hover:bg-gray-50 hover:text-gray-900"
                        )}
                        aria-current={isActive ? "page" : undefined}
                      >
                        <item.icon className="w-5 h-5 flex-shrink-0" />
                        <span
                          className={cn(
                            "transition-all duration-300 ease-in-out overflow-hidden whitespace-nowrap",
                            shouldShowExpanded
                              ? "opacity-100 ml-3 w-auto"
                              : "opacity-0 ml-0 w-0"
                          )}
                        >
                          {item.title}
                        </span>
                      </Link>
                    </ul>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>
      </aside>
    </TooltipProvider>
  );
}
