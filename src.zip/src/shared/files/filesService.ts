// src/shared/files/filesService.ts
import http from "@/shared/api/http";
import { routes } from "@/shared/api/routes";
import { unwrapAny } from "@/shared/api/response";
import type { UploadType, GetFilesData, PostFilesData } from "./types";

export async function listFiles(type: UploadType, referenceId: string) {
  const url = routes.files.byQuery({ type, referenceId });
  const res = await http.get(url);
  return unwrapAny<GetFilesData>(res);
}

export async function uploadFiles(
  type: UploadType,
  referenceId: string,
  files: File[]
) {
  const url = routes.files.byQuery({ type, referenceId });

  const form = new FormData();

  if (type === "logo") {
    // ⚠️ la mayoría de backends esperan "file" para un solo archivo
    const f = files[0];
    form.append("file", f, f.name);
  } else {
    // document → múltiples
    for (const f of files) form.append("files", f, f.name);
    // si tu backend esperara files[] descomenta esto:
    // for (const f of files) form.append("files[]", f, f.name);
  }

  // 👇 Sobrescribe el Content-Type del Axios instance (que tiene application/json)
  // Deja que el navegador ponga el boundary correcto
  const res = await http.post(url, form, {
    headers: { "Content-Type": "multipart/form-data" },
    transformRequest: (data) => data, // evita transformaciones
  });

  return unwrapAny<PostFilesData>(res);
}
