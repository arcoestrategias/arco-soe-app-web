// export const mockProjects = [
//   {
//     id: 1,
//     iniciales: "PI",
//     color: "bg-blue-500",
//     titulo:
//       "Proyecto Integral de Creación y Desarrollo del Área de Ingeniería de Software",
//     descripcion:
//       "Creación del área de Ingeniería de Software, contratación de personal, procesos ágiles y herramientas DevOps. Creación del área de Ingeniería de Software, contratación de personal, procesos ágiles y herramientas DevOps. Creación del área de Ingeniería de Software, contratación de personal, procesos ágiles y herramientas DevOps. Creación del área de Ingeniería de Software, contratación de personal, procesos ágiles y herramientas DevOps.",
//     fechaInicio: "2025-05-01",
//     fechaFin: "2025-12-31",
//     cumplimiento: 25,
//     metaEstrategica:
//       "Cumplir al 100% con todas las prioridades estratégicas y proyectos programados de la empresa de manera mensual. Cumplir al 100% con todas las prioridades estratégicas y proyectos programados de la empresa de manera mensual. Cumplir al 100% con todas las prioridades estratégicas y proyectos programados de la empresa de manera mensual. Cumplir al 100% con todas las prioridades estratégicas y proyectos programados de la empresa de manera mensual. Cumplir al 100% con todas las prioridades estratégicas y proyectos programados de la empresa de manera mensual.",
//     presupuestoProyecto: 150000,
//     presupuestoReal: 37500,
//     totalTareas: 25,
//     tareasCompletadas: 4,
//     factoresClave: 8,
//   },
//   {
//     id: 2,
//     iniciales: "PR",
//     color: "bg-yellow-500",
//     titulo: "Proyecto de Rediseño de la experiencia de clientes",
//     descripcion:
//       "Mejorar la experiencia de clientes mediante rediseño de procesos y plataformas.",
//     fechaInicio: "2025-07-01",
//     fechaFin: "2025-12-31",
//     cumplimiento: 0,
//     metaEstrategica:
//       "Cumplir al 100% prioridades y proyectos programados mensualmente.",
//     presupuestoProyecto: 80000,
//     presupuestoReal: 0,
//     totalTareas: 8,
//     tareasCompletadas: 0,
//     factoresClave: 5,
//   },
//   {
//     id: 3,
//     iniciales: "DT",
//     color: "bg-green-500",
//     titulo: "Digitalización y Transformación Tecnológica",
//     descripcion:
//       "Implementación de sistemas digitales, automatización, BI, IA y modernización tecnológica.",
//     fechaInicio: "2025-03-15",
//     fechaFin: "2025-11-30",
//     cumplimiento: 45,
//     metaEstrategica:
//       "Incrementar la eficiencia operativa organizacional en un mínimo del 30% mediante tecnologías disruptivas.",
//     presupuestoProyecto: 200000,
//     presupuestoReal: 90000,
//     totalTareas: 32,
//     tareasCompletadas: 14,
//     factoresClave: 12,
//   },
//   {
//     id: 4,
//     iniciales: "ES",
//     color: "bg-purple-500",
//     titulo: "Estrategia de Sostenibilidad Empresarial",
//     descripcion:
//       "Desarrollo de políticas y prácticas sostenibles para la organización.",
//     fechaInicio: "2025-02-01",
//     fechaFin: "2025-10-31",
//     cumplimiento: 60,
//     metaEstrategica:
//       "Reducir huella de carbono en 30% y obtener certificación ISO 14001.",
//     presupuestoProyecto: 120000,
//     presupuestoReal: 72000,
//     totalTareas: 18,
//     tareasCompletadas: 11,
//     factoresClave: 6,
//   },
// ];
