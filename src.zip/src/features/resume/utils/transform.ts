// import { RoleSummary } from "@/features/resumen/types/types";

// export function mapToScatterData(roles: RoleSummary[]) {
//   return roles.map((r) => ({
//     id: r.id,
//     x: r.icp,
//     y: r.ico,
//     z: 10,
//     nombre: r.cargo,
//   }));
// }
