"use client";

type IcoBoardProps = {
  planId?: string;
  positionId?: string;
  year?: number | string;
};

export function IcoBoard(_props: IcoBoardProps) {
  return <div>ICO Board</div>;
}
