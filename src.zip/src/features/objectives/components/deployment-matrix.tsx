"use client";

type DeploymentMatrixProps = {
  planId?: string;
  positionId?: string;
  year?: number | string;
};

export function DeploymentMatrix(_props: DeploymentMatrixProps) {
  return <div>Deployment Matrix</div>;
}
