"use client";

type ObjectivesComplianceProps = {
  planId?: string;
  positionId?: string;
  year?: number | string;
};

export function ObjectivesCompliance(_props: ObjectivesComplianceProps) {
  return <div>Objectives Compliance</div>;
}
